import React, { useState, useEffect } from 'react';
import {
    Container,
    Grid,
    Card,
    CardContent,
    Typography,
    Button,
    IconButton,
    TextField,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import StopIcon from '@mui/icons-material/Stop';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';

function Dashboard() {
    const [sites, setSites] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [newSite, setNewSite] = useState({ name: '', template: 'html' });

    useEffect(() => {
        fetchSites();
    }, []);

    const fetchSites = async () => {
        try {
            const response = await axios.get('/api/sites/user/123'); // TODO: Replace with actual user ID
            setSites(response.data);
        } catch (error) {
            console.error('Error fetching sites:', error);
        }
    };

    const handleCreateSite = async () => {
        try {
            await axios.post('/api/sites', {
                ...newSite,
                userId: '123' // TODO: Replace with actual user ID
            });
            setOpenDialog(false);
            setNewSite({ name: '', template: 'html' });
            fetchSites();
        } catch (error) {
            console.error('Error creating site:', error);
        }
    };

    const toggleSiteStatus = async (siteId, currentStatus) => {
        try {
            await axios.post(`/api/sites/${siteId}/toggle`);
            fetchSites();
        } catch (error) {
            console.error('Error toggling site:', error);
        }
    };

    const deleteSite = async (siteId) => {
        if (window.confirm('Are you sure you want to delete this site?')) {
            try {
                await axios.delete(`/api/sites/${siteId}`);
                fetchSites();
            } catch (error) {
                console.error('Error deleting site:', error);
            }
        }
    };

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
            <Typography variant="h4" gutterBottom>
                My Websites
            </Typography>

            <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => setOpenDialog(true)}
                sx={{ mb: 3 }}
            >
                Create New Site
            </Button>

            <Grid container spacing={3}>
                {sites.map((site) => (
                    <Grid item xs={12} md={6} lg={4} key={site._id}>
                        <Card>
                            <CardContent>
                                <Typography variant="h6" gutterBottom>
                                    {site.name}
                                </Typography>
                                <Typography color="textSecondary" gutterBottom>
                                    {site.domain}
                                </Typography>
                                <Typography 
                                    color={site.status === 'active' ? 'success.main' : 'error.main'}
                                    gutterBottom
                                >
                                    Status: {site.status}
                                </Typography>
                                <div style={{ display: 'flex', gap: '8px' }}>
                                    <IconButton 
                                        onClick={() => toggleSiteStatus(site._id, site.status)}
                                        color={site.status === 'active' ? 'error' : 'success'}
                                    >
                                        {site.status === 'active' ? <StopIcon /> : <PlayArrowIcon />}
                                    </IconButton>
                                    <IconButton 
                                        onClick={() => deleteSite(site._id)}
                                        color="error"
                                    >
                                        <DeleteIcon />
                                    </IconButton>
                                    <Button 
                                        variant="outlined" 
                                        size="small"
                                        href={`/site/${site._id}`}
                                    >
                                        Edit
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>

            <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
                <DialogTitle>Create New Website</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Site Name"
                        fullWidth
                        value={newSite.name}
                        onChange={(e) => setNewSite({...newSite, name: e.target.value})}
                    />
                    <TextField
                        margin="dense"
                        label="Template"
                        select
                        fullWidth
                        value={newSite.template}
                        onChange={(e) => setNewSite({...newSite, template: e.target.value})}
                        SelectProps={{
                            native: true,
                        }}
                    >
                        <option value="html">HTML</option>
                        <option value="nodejs">Node.js</option>
                        <option value="react">React</option>
                        <option value="php">PHP</option>
                    </TextField>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
                    <Button onClick={handleCreateSite} variant="contained">
                        Create
                    </Button>
                </DialogActions>
            </Dialog>
        </Container>
    );
}

export default Dashboard;