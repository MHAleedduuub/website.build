const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const router = express.Router();
const FileManager = require('../services/fileManager');

// إعداد multer للرفع
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join('uploads', 'temp');
        fs.ensureDirSync(uploadPath);
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage,
    limits: { fileSize: 100 * 1024 * 1024 } // 100MB
});

// رفع ملف
router.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const { siteId, path: filePath } = req.body;
        const result = await FileManager.uploadFile(siteId, req.file, filePath);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// رفع ملف ZIP
router.post('/upload-zip', upload.single('zip'), async (req, res) => {
    try {
        const { siteId } = req.body;
        const result = await FileManager.extractZip(siteId, req.file.path);
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// عرض محتويات مجلد
router.get('/list/:siteId', async (req, res) => {
    try {
        const files = await FileManager.listFiles(
            req.params.siteId, 
            req.query.path || ''
        );
        res.json(files);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إنشاء مجلد
router.post('/folder/:siteId', async (req, res) => {
    try {
        const { path: folderPath } = req.body;
        const result = await FileManager.createFolder(
            req.params.siteId, 
            folderPath
        );
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// قراءة ملف
router.get('/read/:siteId', async (req, res) => {
    try {
        const { filePath } = req.query;
        const content = await FileManager.readFile(
            req.params.siteId, 
            filePath
        );
        res.json(content);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// حفظ ملف
router.post('/save/:siteId', async (req, res) => {
    try {
        const { filePath, content } = req.body;
        const result = await FileManager.writeFile(
            req.params.siteId, 
            filePath, 
            content
        );
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;