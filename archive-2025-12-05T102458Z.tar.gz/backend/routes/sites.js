const express = require('express');
const router = express.Router();
const Site = require('../models/Site');
const SiteCreator = require('../services/siteCreator');

// إنشاء موقع جديد
router.post('/', async (req, res) => {
    try {
        const { name, template, userId } = req.body;
        
        const result = await SiteCreator.createSite({
            userId,
            name,
            template: template || 'html'
        });
        
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على جميع مواقع المستخدم
router.get('/user/:userId', async (req, res) => {
    try {
        const sites = await Site.find({ owner: req.params.userId });
        res.json(sites);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// تشغيل/إيقاف موقع
router.post('/:id/toggle', async (req, res) => {
    try {
        const site = await Site.findById(req.params.id);
        site.status = site.status === 'active' ? 'stopped' : 'active';
        await site.save();
        res.json(site);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// حذف موقع
router.delete('/:id', async (req, res) => {
    try {
        await Site.findByIdAndDelete(req.params.id);
        res.json({ message: 'Site deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;