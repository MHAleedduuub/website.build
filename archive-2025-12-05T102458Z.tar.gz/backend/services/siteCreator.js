const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const Site = require('../models/Site');
const User = require('../models/User');

class SiteCreator {
    constructor() {
        this.baseDir = path.join(__dirname, '../../websites');
    }
    
    async createSite(data) {
        const { userId, name, template = 'html' } = data;
        
        try {
            // إنشاء معرف فريد للموقع
            const siteId = uuidv4();
            const userDir = path.join(this.baseDir, userId);
            const siteDir = path.join(userDir, siteId);
            
            // إنشاء الدلائل
            await fs.ensureDir(siteDir);
            await fs.ensureDir(path.join(siteDir, 'public'));
            await fs.ensureDir(path.join(siteDir, 'logs'));
            
            // توليد الدومين
            const domain = `${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}.${userId}.localhost`;
            
            // إنشاء ملفات الموقع الأساسية
            await this.createSiteFiles(siteDir, template, { name, domain });
            
            // حفظ الموقع في قاعدة البيانات
            const site = new Site({
                name,
                domain,
                owner: userId,
                template,
                port: 3000 + Math.floor(Math.random() * 1000)
            });
            
            await site.save();
            
            // إضافة الموقع للمستخدم
            await User.findByIdAndUpdate(userId, {
                $push: { sites: site._id }
            });
            
            return {
                success: true,
                siteId: site._id,
                siteDir,
                domain,
                message: 'Site created successfully'
            };
            
        } catch (error) {
            console.error('Error creating site:', error);
            throw error;
        }
    }
    
    async createSiteFiles(siteDir, template, data) {
        const publicDir = path.join(siteDir, 'public');
        
        // إنشاء index.html أساسي
        const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.name}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            background: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background: white;
            padding: 3rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 600px;
        }
        h1 { color: #333; margin-bottom: 1rem; }
        p { color: #666; margin-bottom: 2rem; }
        .domain { 
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            font-family: monospace;
            margin: 1rem 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎉 Welcome to ${data.name}</h1>
        <p>Your website has been created successfully!</p>
        <div class="domain">${data.domain}</div>
        <p>Powered by Hosting Platform</p>
    </div>
</body>
</html>
        `.trim();
        
        await fs.writeFile(path.join(publicDir, 'index.html'), htmlContent);
        
        // إنشاء ملفات إضافية حسب النموذج
        if (template === 'nodejs') {
            await this.createNodeFiles(siteDir, data);
        } else if (template === 'react') {
            await this.createReactFiles(siteDir, data);
        } else if (template === 'php') {
            await this.createPHPFiles(publicDir, data);
        }
    }
    
    async createNodeFiles(siteDir, data) {
        const packageJson = {
            name: data.name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
            version: "1.0.0",
            main: "server.js",
            scripts: {
                start: "node server.js",
                dev: "nodemon server.js"
            },
            dependencies: {
                express: "^4.18.2"
            }
        };
        
        const serverJs = `
const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
        `.trim();
        
        await fs.writeJson(path.join(siteDir, 'package.json'), packageJson, { spaces: 2 });
        await fs.writeFile(path.join(siteDir, 'server.js'), serverJs);
    }
    
    async deleteSite(siteId) {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const siteDir = path.join(this.baseDir, site.owner.toString(), site._id.toString());
            
            // حذف الملفات
            if (await fs.pathExists(siteDir)) {
                await fs.remove(siteDir);
            }
            
            // حذف من قاعدة البيانات
            await Site.findByIdAndDelete(siteId);
            
            return { success: true, message: 'Site deleted successfully' };
            
        } catch (error) {
            throw error;
        }
    }
}

module.exports = new SiteCreator();