const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const unzipper = require('unzipper');

class FileManager {
    constructor() {
        this.baseDir = path.join(__dirname, '../../websites');
    }
    
    async listFiles(siteId, relativePath = '') {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const siteDir = path.join(this.baseDir, site.owner.toString(), site._id.toString(), 'public');
            const targetDir = path.join(siteDir, relativePath);
            
            if (!await fs.pathExists(targetDir)) {
                throw new Error('Directory does not exist');
            }
            
            const items = await fs.readdir(targetDir, { withFileTypes: true });
            
            const files = await Promise.all(items.map(async (item) => {
                const itemPath = path.join(targetDir, item.name);
                const stats = await fs.stat(itemPath);
                
                return {
                    name: item.name,
                    type: item.isDirectory() ? 'directory' : 'file',
                    path: path.join(relativePath, item.name).replace(/\/g, '/'),
                    size: stats.size,
                    modified: stats.mtime,
                    created: stats.birthtime
                };
            }));
            
            // ترتيب: مجلدات أولاً ثم ملفات
            return files.sort((a, b) => {
                if (a.type === 'directory' && b.type !== 'directory') return -1;
                if (a.type !== 'directory' && b.type === 'directory') return 1;
                return a.name.localeCompare(b.name);
            });
            
        } catch (error) {
            throw error;
        }
    }
    
    async readFile(siteId, filePath) {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const fullPath = path.join(
                this.baseDir, 
                site.owner.toString(), 
                site._id.toString(), 
                'public', 
                filePath
            );
            
            if (!await fs.pathExists(fullPath)) {
                throw new Error('File not found');
            }
            
            const content = await fs.readFile(fullPath, 'utf8');
            const stats = await fs.stat(fullPath);
            
            return {
                content,
                stats: {
                    size: stats.size,
                    modified: stats.mtime,
                    created: stats.birthtime
                }
            };
            
        } catch (error) {
            throw error;
        }
    }
    
    async writeFile(siteId, filePath, content) {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const fullPath = path.join(
                this.baseDir, 
                site.owner.toString(), 
                site._id.toString(), 
                'public', 
                filePath
            );
            
            // التأكد من وجود المجلد
            await fs.ensureDir(path.dirname(fullPath));
            
            // حفظ الملف
            await fs.writeFile(fullPath, content, 'utf8');
            
            return { success: true, message: 'File saved' };
            
        } catch (error) {
            throw error;
        }
    }
    
    async createFolder(siteId, folderPath) {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const fullPath = path.join(
                this.baseDir, 
                site.owner.toString(), 
                site._id.toString(), 
                'public', 
                folderPath
            );
            
            await fs.ensureDir(fullPath);
            
            return { success: true, message: 'Folder created' };
            
        } catch (error) {
            throw error;
        }
    }
    
    async uploadFile(siteId, file, destination = '') {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const destPath = path.join(
                this.baseDir,
                site.owner.toString(),
                site._id.toString(),
                'public',
                destination,
                file.originalname
            );
            
            await fs.ensureDir(path.dirname(destPath));
            await fs.move(file.path, destPath, { overwrite: true });
            
            return { success: true, path: destPath };
            
        } catch (error) {
            throw error;
        }
    }
    
    async extractZip(siteId, zipPath, destination = '') {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const destDir = path.join(
                this.baseDir,
                site.owner.toString(),
                site._id.toString(),
                'public',
                destination
            );
            
            await fs.ensureDir(destDir);
            
            // استخراج ملف ZIP
            await new Promise((resolve, reject) => {
                fs.createReadStream(zipPath)
                    .pipe(unzipper.Extract({ path: destDir }))
                    .on('close', resolve)
                    .on('error', reject);
            });
            
            // حذف ملف ZIP الأصلي
            await fs.remove(zipPath);
            
            return { success: true, message: 'ZIP extracted' };
            
        } catch (error) {
            throw error;
        }
    }
    
    async createZip(siteId, files, zipName) {
        try {
            const site = await Site.findById(siteId);
            if (!site) {
                throw new Error('Site not found');
            }
            
            const siteDir = path.join(
                this.baseDir,
                site.owner.toString(),
                site._id.toString(),
                'public'
            );
            
            const zipPath = path.join(
                this.baseDir,
                site.owner.toString(),
                site._id.toString(),
                'backups',
                zipName
            );
            
            await fs.ensureDir(path.dirname(zipPath));
            
            return new Promise((resolve, reject) => {
                const output = fs.createWriteStream(zipPath);
                const archive = archiver('zip', { zlib: { level: 9 } });
                
                output.on('close', () => {
                    resolve({ 
                        success: true, 
                        zipPath,
                        size: archive.pointer() 
                    });
                });
                
                archive.on('error', reject);
                archive.pipe(output);
                
                files.forEach(file => {
                    const filePath = path.join(siteDir, file);
                    if (fs.existsSync(filePath)) {
                        if (fs.statSync(filePath).isDirectory()) {
                            archive.directory(filePath, file);
                        } else {
                            archive.file(filePath, { name: file });
                        }
                    }
                });
                
                archive.finalize();
            });
            
        } catch (error) {
            throw error;
        }
    }
}

module.exports = new FileManager();