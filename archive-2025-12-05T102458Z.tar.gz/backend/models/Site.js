const mongoose = require('mongoose');

const SiteSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    domain: {
        type: String,
        required: true,
        unique: true
    },
    owner: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    status: {
        type: String,
        enum: ['active', 'stopped', 'building'],
        default: 'active'
    },
    template: {
        type: String,
        default: 'html'
    },
    language: {
        type: String,
        default: 'html'
    },
    port: {
        type: Number,
        default: 3000
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    settings: {
        ssl: {
            type: Boolean,
            default: false
        },
        analytics: {
            type: Boolean,
            default: false
        },
        backups: {
            type: Boolean,
            default: true
        }
    }
});

module.exports = mongoose.model('Site', SiteSchema);