const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    plan: {
        type: String,
        default: 'free',
        enum: ['free', 'pro', 'business']
    },
    sites: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Site'
    }]
});

module.exports = mongoose.model('User', UserSchema);