# 🚀 Professional Hosting Platform

A complete website hosting platform with AI support, file management, and multi-language support.

## Features

- ✅ Create websites with one click
- ✅ Support for HTML, Node.js, React, PHP, Python
- ✅ File manager with ZIP support
- ✅ AI-powered code assistance
- ✅ Start/stop websites
- ✅ Custom domains (site.user.localhost)
- ✅ Docker support
- ✅ User authentication

## Quick Start

### Method 1: Docker (Recommended)

```bash
# 1. Clone or create the project
cd hosting-platform

# 2. Start all services
docker-compose up -d

# 3. Access the platform
# Frontend: http://localhost:3000
# Backend API: http://localhost:5000
```

### Method 2: Manual Installation

```bash
# 1. Install MongoDB
# Download from https://www.mongodb.com/try/download/community

# 2. Start MongoDB
mongod

# 3. Install backend dependencies
cd backend
npm install

# 4. Install frontend dependencies
cd ../frontend
npm install

# 5. Start backend (in one terminal)
cd ../backend
npm run dev

# 6. Start frontend (in another terminal)
cd ../frontend
npm start
```

## Project Structure

```
hosting-platform/
├── backend/           # Node.js backend API
├── frontend/          # React frontend
├── websites/          # User websites storage
├── uploads/           # File uploads
├── backups/           # Website backups
├── infra/             # Infrastructure configs
└── docker-compose.yml # Docker setup
```

## API Endpoints

- POST /api/sites - Create new website
- GET /api/sites/user/:userId - Get user websites
- POST /api/sites/:id/toggle - Start/stop website
- POST /api/files/upload - Upload file
- POST /api/files/upload-zip - Upload and extract ZIP
- GET /api/files/list/:siteId - List files
- POST /api/auth/register - Register user
- POST /api/auth/login - Login user

## Development

1. Create a test user:
   - Email: test@example.com
   - Password: password123

2. Create your first website:
   - Name: mysite
   - Template: html

3. Access your site at: mysite.user-id.localhost

## Deployment

1. Update .env with production values
2. Set up SSL certificates
3. Configure domain in nginx config
4. Run: docker-compose up -d --build

## Support

For issues and feature requests, please create an issue on GitHub.